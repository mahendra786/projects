<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
It's highly recommended to use sandbox account for testing purpose
*/

$config['mode']          = "sandbox"; //for live account use the key "live"
$config['client_id']     = 'AXt5Q5O_xouOI-hqazGQg1df-XkM_hDfOdiitN5MkmRfK4Q_7FBP6JHYo3BuQbCzNxoXScYU9833P0uw'; //provide your client ID
$config['client_secret'] = 'EMdSqevavkJ96OpgnG7rYNU9nFrvXJLipDpoyO65CaK0ojrEnwbX4c3-fo3o7KlSetRxlDjGf4ykRo3j'; //provide your secret ID
$config['currency']      = 'INR'; //provide the currency code you want to use