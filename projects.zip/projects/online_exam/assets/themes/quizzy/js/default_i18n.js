/**
 *
 * You can write your JS code for default theme here
 *
 */

(function ($) {
  "use strict";
  $(document).ready(function () {});
})(jQuery);
