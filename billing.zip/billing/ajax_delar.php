<?php
include('connect.php');
$q = $_POST["keyword"];
// echo $q;die;
 $sql="select id,name from users WHERE name like '%" . $_POST["keyword"] . "%' and user_level='3'";
 // echo "select name from users WHERE name like '%" . $_POST["keyword"] . "%' and user_level='3'";die;
$sql=$conn->query($sql);
   // $row=$result->fetch_assoc();


// print_r($result);die;
 
?>


<ul id="country-list">
<?php
$mm = mysqli_num_rows($sql);
// echo $mm;
if($mm>0)
{
	// echo "aa";die;
while($result = mysqli_fetch_array($sql)) {
	// print_r($result);
?>
<li onClick="selectCountry('<?php echo $result["id"]; ?>','<?php echo $result["name"]; ?>');"><?php echo $result["name"]; ?></li>
<?php } 
}
else
{
	?>
<li>No result found</li>
	<?php
}
?>
</ul>

