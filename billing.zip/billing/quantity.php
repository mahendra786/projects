<?php
include("check.php");
?>
<?php
include("connect.php");
include("header.php");



if($_POST['submit'])
{
 echo "aa";die;
}


$sql3= "SELECT * from products where quantity<20";
$result3=$conn->query($sql3);



?>
<div class="pcoded-content">
<div class="pcoded-inner-content">

<div class="main-body">
<div class="page-wrapper">

<div class="page-header">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<div class="d-inline">
<h4>Product Quantity</h4>


</div>
</div>
</div>
<div class="col-lg-4">
<div class="page-header-breadcrumb">
<ul class="breadcrumb-title">
<li class="breadcrumb-item">
<a href=""> <i class="feather icon-home"></i> </a>
</li>
<li class="breadcrumb-item"><a>Quantity</a>
</li>
<li class="breadcrumb-item"><a href="">Quantity</a>
</li>
</ul>
</div>
</div>
</div>
</div>

<div class="page-body">

<div class="card">

<div class="card-block">
<hr>
<?php if(!empty($_GET['msg']))
{
    ?>

<div class="alert alert-success">
  <strong>Success!</strong> <?= $_GET['msg']; ?>
</div>
<?php } ?>

<?php if(!empty($_GET['errormsg']))
{
    ?>

<div class="alert alert-danger">
   <?= $_GET['errormsg']; ?>
</div>
<?php } ?>
<div class="table-responsive dt-responsive">
<table id="dom-jqry" class="table table-striped table-bordered nowrap">
<thead>
                <tr>
                    <th>Id</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <!-- <th>Photo Type</th> -->
                    <th>Action</th>
                    
                </tr>
            </thead>
            <tbody>

<?php
foreach ($result3 as $row3) {
  
  ?>
  <tr>
    <td><?php echo $row3['id']; ?></td>
    <td><?php echo $row3['name']; ?></td>
    <td>
  <?php echo $row3['quantity']; ?>
                  </td>
    

    
    <td>  
            



<!-- The Modal -->
<div class="modal" id="myModal11">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Quantity</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
<form method="post" action="editquantity2.php">
  <input type="hidden" name="pid" value="<?php echo $row3['id']; ?>">
       <input type="number" name="quantity" class="form-control" style="width:90%;" placeholder="Enter Quantity" value="<?php echo $row3['quantity']; ?>"/>
       <br>
       <input type="submit" name="quantity_add" value="Save" class="btn btn-success">
        <!-- <button type="submit" name="quantity_add"  data-dismiss="modal">Save</button> -->
</form>
      </div>

      <!-- Modal footer -->
    

    </div>
  </div>
</div>


          <a href="#" data-toggle="modal" data-target="#myModal11" >  <input id="delete" type="submit" name="delete" value="Add Quantity" class="btn btn-success" /></a>
        </td>
          </tr>
<?php 
}
?>

                                               
                                        </tbody>
</table>
</div>
</div>
</div>


</div>

</div>
</div>

<div id="#">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<?php include("footer.php"); ?>

<!--  Author Name: Nikhil Bhalerao - www.nikhilbhalerao.com 
PHP, Laravel and Codeignitor Developer -->