<?php
$servername = "localhost";
$username = "test";
$password = "111";
$dbname= "billing";

// Author Name: Nikhil Bhalerao - www.nikhilbhalerao.com 
// PHP, Laravel and Codeignitor Developer

$conn = new mysqli($servername, $username, $password,$dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


 ?>
