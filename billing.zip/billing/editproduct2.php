<?php
include("connect.php");



  $path ="image/";
 
  $image=basename($_FILES['file_upload']['name']);
  $image_name=$path.$image;
  
  if(move_uploaded_file($_FILES['file_upload']['tmp_name'],$image_name))
  {
  // $sql="insert into products(name,quantity,buy_price,sale_price,categorie_id,media,model,vehicle,date)values('".$_POST['name']."','".$_POST['quantity']."','".$_POST['buy_price']."','".$_POST['sale_price']."','".$_POST['categorie_id']."','".$image."','".$_POST['model']."','".$_POST['vehicle']."','". $today."')";

  	$sql="UPDATE products set name='".$_POST['name']."',quantity='".$_POST['quantity']."',buy_price='".$_POST['buy_price']."',sale_price='".$_POST['sale_price']."',categorie_id='".$_POST['categorie_id']."' ,media='".$image."',model='".$_POST['model']."',vehicle='".$_POST['vehicle']."' where id='".$_GET['id']."'";

  }else
  {
    // $sql="insert into products(name,quantity,buy_price,sale_price,categorie_id,date)values('".$_POST['name']."','".$_POST['quantity']."','".$_POST['buy_price']."','".$_POST['sale_price']."','".$_POST['categorie_id']."','".$_POST['model']."','".$_POST['vehicle']."','". $today."')";

    $sql="UPDATE products set name='".$_POST['name']."',quantity='".$_POST['quantity']."',buy_price='".$_POST['buy_price']."',sale_price='".$_POST['sale_price']."',categorie_id='".$_POST['categorie_id']."',model='".$_POST['model']."',vehicle='".$_POST['vehicle']."'  where id='".$_GET['id']."'";

  }


// echo "aa";die;

// echo $sql;die;
$result=$conn->query($sql);
header('location:product.php');
?>