<link rel="stylesheet" type="text/css" href="style.css">
 <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
  </li>
   <li>
      <a href="#"><i class="fa fa-flag fa-fw"></i>User Management<span class="fa arrow"></span></a>
      <ul class="nav nav-second-level">
        <li>
          <a href="groups.php">Manage Groups</a>
        </li>
            <li>
             <a href="users.php">Manage Users</a>
           </li>
       </ul>                                                       
  </li>

  <li>
    <a href="categories.php"><i class="fa fa-table fa-fw"></i>Categories</a>
  </li>

   <li>
      <a href="#"><i class="fa fa-flag fa-fw"></i>Products<span class="fa arrow"></span></a>
      <ul class="nav nav-second-level">
        <li>
          <a href="product.php">Manage products</a>
        </li>
            <li>
             <a href="addproduct.php">Add product</a>
           </li>
       </ul>                                                       
  </li>


  <li>
    <a href="media.php"><i class="fa fa-table fa-fw"></i>Media</a>
  </li>


   <li>
      <a href="#"><i class="fa fa-flag fa-fw"></i>Sales<span class="fa arrow"></span></a>
      <ul class="nav nav-second-level">
        <li>
          <a href="sales.php">Manage sales</a>
        </li>
            <li>
             <a href="addsales.php">Add product</a>
           </li>
       </ul>                                                       
  </li>
                            
                                <a href="#"><i class="fa fa-flag fa-fw"></i>Sales Report<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="salesdatereport.php">Sales by dates</a>
                                    </li>
                                    <li>
                                        <a href="monthly_sales.php">Monthly sales</a>
                                    </li>
                                    <li>
                                        <a href="dailysales.php">Daily sales</a>
                                    </li>
                                    
                                    
                                </ul>
                                                         </li>

                            