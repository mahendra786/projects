<?php
include("connect.php");
$sql="delete from users where id='".$_GET['id']."'";
header('location:users.php?errormsg=Deleted Successfully');
echo 'Deleted successfully.';
if($conn->query($sql))
{
	echo "Record Deleted";
}else
{
	echo "Not Deleted";
}

?>