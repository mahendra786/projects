<?php
include("connect.php");

 $sql="UPDATE user_groups set group_name='".$_POST['group_name']."',group_level='".$_POST['group_level']."',group_status='".$_POST['group_status']."' where id='".$_GET['id']."'";
 // echo $sql;die;
$result1=$conn->query($sql);
header('location:group.php?msg=Updated Successfully');
?>
