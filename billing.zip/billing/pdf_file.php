<?php 
include("connect.php");
// Include autoloader 


$id = $_GET['id'];

$query = "SELECT s.customer_name, s.total, s.remark , p.name,sp.quantity,sp.unit_price FROM sales s LEFT JOIN sales_product sp ON s.id = sp.sales_id LEFT JOIN products p ON p.id = sp.product_id where s.make_by='$id'";
$result = mysqli_query($conn, $query);


$output = "
 <style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
<table>
 <tr>
  <th>Customer Name</th>
  <th>Total</th>
  <th>Remark</th>
  <th>Product Name</th>
  <th>Quantity</th>
  <th>price</th>
 </tr>
";

while($row = mysqli_fetch_array($result))
{
 $output .= '
  <tr>
   <td>'.$row["customer_name"].'</td>
   <td>'.$row["total"].'</td>
   <td>'.$row["remark"].'</td>
    <td>'.$row["name"].'</td>
   <td>'.$row["quantity"].'</td>
   <td>'.$row["unit_price"].'</td>
  </tr>
 ';
}

$output .= '</table>';


// $html = "<table border='1' width='100%' style='border-collapse: collapse;'>
//         <tr>
//             <th>Username</th><th>Email</th>
//         </tr>
//         <tr>
//             <td>yssyogesh</td>
//             <td>yssyogesh@makitweb.com</td>
//         </tr>
//         <tr>
//             <td>sonarika</td>
//             <td>sonarika@gmail.com</td>
//         </tr>
//         <tr>
//             <td>vishal</td>
//             <td>vishal@gmail.com</td>
//         </tr>
//         </table>";
$filename = "sale";

// include autoloader
require_once 'dompdf/autoload.inc.php';

// reference the Dompdf namespace
use Dompdf\Dompdf;

// instantiate and use the dompdf class
$dompdf = new Dompdf();

$dompdf->loadHtml($output);

// (Optional) Setup the paper size and orientation
$dompdf->setPaper('A4', 'landscape');

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF to Browser
$dompdf->stream($filename);







?>	