<?php
include("check.php");
?>
<?php
include("connect.php");
include("header.php");

$sql= "SELECT u.id,u.name,u.username,u.user_level,u.status,u.last_login,g.group_name 
          FROM users u
          LEFT JOIN user_groups g ON g.id=u.user_level 
          where u.delete_status='0' and u.user_level ='2' 
          ORDER BY u.name ASC";
$result=$conn->query($sql);


 
?>
<div class="pcoded-content">
<div class="pcoded-inner-content">

<div class="main-body">
<div class="page-wrapper">

<div class="page-header">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<div class="d-inline">
<h4>Admins</h4>


</div>
</div>
</div>
<div class="col-lg-4">
<div class="page-header-breadcrumb">
<ul class="breadcrumb-title">
<li class="breadcrumb-item">
<a href=""> <i class="feather icon-home"></i> </a>
</li>
<li class="breadcrumb-item"><a>Admins</a>
</li>
<li class="breadcrumb-item"><a href="">Admins</a>
</li>
</ul>
</div>
</div>
</div>
</div>

<div class="page-body">

<div class="card">
<div class="card-header">
    <div class="col-sm-10">
        <a href="adduser.php"><button class="btn btn-primary pull-right">+ Add New</button></a>
    </div>

</div>
<div class="card-block">

<?php if(!empty($_GET['msg']))
{
    ?>

<div class="alert alert-success">
  <strong>Success!</strong> <?= $_GET['msg']; ?>
</div>
<?php } ?>

<?php if(!empty($_GET['errormsg']))
{
    ?>

<div class="alert alert-danger">
   <?= $_GET['errormsg']; ?>
</div>
<?php } ?>
<div class="table-responsive dt-responsive">
<table id="dom-jqry" class="table table-striped table-bordered nowrap">
<thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>User Role</th>
                    <th>Status</th>
                    <th>Last Login</th>
                      <?php if($_SESSION['level']==1)
            { ?>
                    <th>Action</th>
                <?php } ?>
                </tr>
            </thead>
            <tbody>

<?php
if(!empty($result))
{
    // echo "<pre>";
// print_r($result);
foreach ($result as $row) 
{
     
    ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['username']; ?></td>
        <td><?php echo $row['group_name']; ?></td>
        <td><?php if($row['status']==1){
      echo "<span style='background-color:green;color:#fff;padding: 0px 10px 0px 10px;font-size:14px;'>Active</span>";  
        }else{ echo "<span style='background-color:red;color:#fff;padding: 0px 10px 0px 10px;font-size:14px;'>Deactive</span>"; }
        ?></td>
        <td><?php echo  $row['last_login']; ?></td>
        <td>    
            <?php if($_SESSION['level']==1)
            { ?>
            <a href="edituser.php?id=<?php echo $row['id']?>"><input id="edit" type="submit" name="edit" value="Edit" class="btn btn-success"/></a>
             <a href="deleteuser.php?id=<?php echo $row['id']?>" onclick="return confirm('Are you sure to delete this record?')">  <input id="delete" type="submit" name="delete" value="Delete" class="btn btn-danger" /></a>
        <?php } ?>
         
        </td>
            </tr>
<?php   
}
}
?>

                                               
                                        </tbody>
</table>
</div>
</div>
</div>


</div>

</div>
</div>

<div id="#">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php include("footer.php"); ?>

<!--  Author Name: Nikhil Bhalerao - www.nikhilbhalerao.com 
PHP, Laravel and Codeignitor Developer -->