<?php 
include("connect.php");
$id = $_GET['id'];



$sql = "SELECT s.customer_name, s.total, s.remark , p.name,sp.quantity,sp.unit_price FROM sales s LEFT JOIN sales_product sp ON s.id = sp.sales_id LEFT JOIN products p ON p.id = sp.product_id where s.make_by='$id'";  
    // echo $sql;die;
$setRec = mysqli_query($conn, $sql);  
$columnHeader = '';  
$columnHeader = "Customer Name" . "\t" . "Total" . "\t" . "Remark" . "\t"  . "Product Name" . "\t"  . "Quantity" . "\t"  . "Unit Price" . "\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  

    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=sale.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n"; 
?>	