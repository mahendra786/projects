<?php
include("connect.php");
$pid = $_POST['pid'];
$quantity = $_POST['quantity'];
$sql="UPDATE products  set quantity='$quantity' where id = '$pid'";
$result=$conn->query($sql);

header('location:quantity.php?msg=Quantity updated successfully');
?>